# Aucun parsing requis pour le TP4. Le code Pithon est directement écrit sous forme de listes.
# Exemple : ["print", "Bonjour"] ou ["class", "Personne", {...}]